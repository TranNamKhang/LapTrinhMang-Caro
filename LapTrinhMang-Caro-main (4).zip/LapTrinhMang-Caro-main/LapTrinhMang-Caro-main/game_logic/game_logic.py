﻿BOARD_SIZE = 15

class GameLogic:
    def __init__(self):
        self.reset()

    def reset(self):
        """Khởi tạo bàn cờ trống"""
        self.board = [[None for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]
        self.moves = 0
        self.winner = None

    def is_valid_move(self, x, y):
        return 0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE and self.board[y][x] is None

    def make_move(self, x, y, mark):
        if not self.is_valid_move(x, y) or self.winner:
            return False
        self.board[y][x] = mark
        self.moves += 1

        if self.check_win(x, y, mark):
            self.winner = mark
        elif self.moves == BOARD_SIZE * BOARD_SIZE:
            self.winner = "DRAW"
        return True

    def check_win(self, x, y, mark):
        directions = [(1,0), (0,1), (1,1), (1,-1)]
        for dx, dy in directions:
            count = 1
            i = 1
            while self.in_bounds(x - dx*i, y - dy*i) and self.board[y - dy*i][x - dx*i] == mark:
                count += 1
                i += 1
            i = 1
            while self.in_bounds(x + dx*i, y + dy*i) and self.board[y + dy*i][x + dx*i] == mark:
                count += 1
                i += 1
            if count >= 5:
                return True
        return False

    def in_bounds(self, x, y):
        return 0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE

    def get_winner(self):
        return self.winner

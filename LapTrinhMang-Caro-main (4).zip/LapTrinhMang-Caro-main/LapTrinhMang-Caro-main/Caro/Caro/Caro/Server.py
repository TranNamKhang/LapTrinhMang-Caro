﻿#!/usr/bin/env python3
import socket
import threading

PORT = 5000
BOARD_SIZE = 15

class GameRoom:
    def __init__(self, player1, player2):
        self.board = [[None for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]
        self.players = {"X": player1, "O": player2}
        self.turn = "X"
        player1.mark = "X"
        player2.mark = "O"
        player1.room = self
        player2.room = self
        self.start_game()

    def start_game(self):
        self.players["X"].send("START X\n")
        self.players["O"].send("START O\n")
        self.update_turn()

    def update_turn(self):
        for mark, p in self.players.items():
            if mark == self.turn:
                p.send("YOUR_TURN\n")
            else:
                p.send("WAIT\n")

    def handle_move(self, player, x, y):
        if player.mark != self.turn:
            player.send("ERR Not your turn\n")
            return
        if not (0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE):
            player.send("ERR Out of bounds\n")
            return
        if self.board[y][x] is not None:
            player.send("ERR Cell occupied\n")
            return

        self.board[y][x] = player.mark
        player.send(f"OK MOVE {x} {y}\n")
        other_mark = "O" if player.mark == "X" else "X"
        self.players[other_mark].send(f"OPPONENT_MOVE {x} {y}\n")

        if self.check_win(x, y, player.mark):
            player.send("RESULT WIN\n")
            self.players[other_mark].send("RESULT LOSE\n")
            self.end_game()
        elif self.is_draw():
            for p in self.players.values():
                p.send("RESULT DRAW\n")
            self.end_game()
        else:
            self.turn = other_mark
            self.update_turn()

    def handle_chat(self, sender, message):
        """Gửi tin nhắn từ 1 player cho player kia"""
        other_mark = "O" if sender.mark == "X" else "X"
        if other_mark in self.players:
            self.players[other_mark].send(f"CHAT {sender.mark}: {message}\n")
        sender.send(f"CHAT You: {message}\n")

    def check_win(self, x, y, mark):
        directions = [(1,0), (0,1), (1,1), (1,-1)]
        for dx, dy in directions:
            count = 1
            for dir in [1,-1]:
                nx, ny = x, y
                while True:
                    nx += dx * dir
                    ny += dy * dir
                    if 0 <= nx < BOARD_SIZE and 0 <= ny < BOARD_SIZE and self.board[ny][nx] == mark:
                        count += 1
                    else:
                        break
            if count >= 5:
                return True
        return False

    def is_draw(self):
        return all(cell is not None for row in self.board for cell in row)

    def end_game(self):
        for p in self.players.values():
            p.room = None


class ClientThread(threading.Thread):
    def __init__(self, sock, addr, server):
        super().__init__(daemon=True)
        self.sock = sock
        self.addr = addr
        self.server = server
        self.room = None
        self.mark = None
        self.buffer = ""

    def run(self):
        try:
            self.send("CONNECTED\n")
            self.server.add_waiting(self)
            while True:
                data = self.sock.recv(1024)
                if not data:
                    break
                self.buffer += data.decode(errors="ignore")
                while "\n" in self.buffer:
                    line, self.buffer = self.buffer.split("\n", 1)
                    self.handle_line(line.strip())
        except Exception as e:
            print(f"Client {self.addr} error: {e}")
        finally:
            self.cleanup()

    def handle_line(self, line):
        parts = line.split(maxsplit=2)
        if not parts:
            return
        cmd = parts[0].upper()
        if cmd == "MOVE" and len(parts) == 3:
            try:
                x, y = int(parts[1]), int(parts[2])
                if self.room:
                    self.room.handle_move(self, x, y)
            except:
                self.send("ERR Invalid move\n")
        elif cmd == "CHAT" and len(parts) >= 2:
            message = parts[1] if len(parts) == 2 else parts[1] + " " + parts[2]
            if self.room:
                self.room.handle_chat(self, message)
            else:
                self.send("ERR Not in room\n")
        else:
            self.send("ERR Unknown command\n")

    def send(self, msg):
        try:
            self.sock.sendall(msg.encode())
        except:
            pass

    def cleanup(self):
        if self.room:
            other_mark = "O" if self.mark == "X" else "X"
            if other_mark in self.room.players:
                opp = self.room.players[other_mark]
                opp.send("RESULT OPPONENT_LEFT\n")
                opp.room = None
        self.sock.close()


class CaroServer:
    def __init__(self, port):
        self.port = port
        self.waiting = None

    def add_waiting(self, player):
        if self.waiting is None:
            self.waiting = player
            player.send("STATUS Waiting for opponent...\n")
        else:
            GameRoom(self.waiting, player)
            self.waiting.send("STATUS Opponent found!\n")
            player.send("STATUS Opponent found!\n")
            self.waiting = None

    def start(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", self.port))
            s.listen()
            print(f"Server listening on port {self.port}")
            while True:
                conn, addr = s.accept()
                print(f"Client connected: {addr}")
                ClientThread(conn, addr, self).start()


if __name__ == "__main__":
    server = CaroServer(PORT)
    server.start()
